<div class="px-20 mx-auto py-16 ">
    <h2 class="text-2xl font-bold  p-4 text-center">Loan Types</h2>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        <?php $__currentLoopData = $loanTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loanType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white p-6 rounded-lg shadow-lg transition transform hover:-translate-y-1">
                <img src="<?php echo e(asset('storage/'. $loanType->image )); ?>" alt="<?php echo e($loanType->title); ?>" class="w-full h-48 object-cover object-center mb-4 rounded">
                <h2 class="text-xl font-semibold mb-2"><?php echo e($loanType->title); ?></h2>
                <p class="text-gray-700"><?php echo e($loanType->description); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH G:\projects\laravel\plussave_website\resources\views\livewire\loan-types.blade.php ENDPATH**/ ?>