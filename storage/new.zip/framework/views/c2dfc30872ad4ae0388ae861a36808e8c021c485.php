<div class="max-w-4xl mx-auto py-8">
    <div class="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <?php $__empty_1 = true; $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                <div class="p-6">
                    <h2 class="text-xl font-semibold text-green-700 mb-4"><?php echo e($faq->question); ?></h2>
                    <p class="text-gray-700"><?php echo e($faq->answer); ?></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-gray-700">No FAQs available at the moment.</p>
        <?php endif; ?>
    </div>

    <div class="mt-6">
        <?php echo e($faqs->links()); ?>

    </div>
</div>
<?php /**PATH G:\projects\laravel\plussave_website\resources\views\livewire\faqs.blade.php ENDPATH**/ ?>