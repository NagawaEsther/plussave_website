<div >

    <!-- financial-advice-component.blade.php -->
<div class="p-6">
    <h2 class="text-2xl font-bold mb-4 text-green-700">Financial Advice</h2>
    <?php $__currentLoopData = $financialAdvice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="mb-4 p-4 border rounded flex items-start">
        <div class="mr-4 text-green-700">
            <i class="fas fa-comments fa-2x"></i>
        </div>
        <div>
            <h3 class="text-lg font-bold"><?php echo e($advice->title); ?></h3>
            <p><?php echo e($advice->content); ?></p>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo e($financialAdvice->links()); ?>

</div>

</div>
<?php /**PATH G:\projects\laravel\plussave_website\resources\views\livewire\financial-advice-component.blade.php ENDPATH**/ ?>