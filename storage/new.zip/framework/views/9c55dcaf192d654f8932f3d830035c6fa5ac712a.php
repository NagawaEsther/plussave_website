<div class="space-x-10">
    <?php $__currentLoopData = $accountTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accountType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="px-20 mx-auto bg-whiterounded-lg overflow-hidden">
        <div class="grid grid-cols-1 md:grid-cols-2 p-4">
            <div class="py-4 px-3">
                <img class="w-full object-contain rounded-lg mt-3" src="<?php echo e(asset('storage/' . str_replace('\\', '/', $accountType->image))); ?>" alt="<?php echo e($accountType->title); ?>">
            </div>
            <div class="p-6">
                <h2 class="text-2xl font-bold mb-2 text-green-700"><?php echo e($accountType->title); ?></h2>
                <p class="text-gray-700 mb-4"><?php echo e($accountType->description); ?></p>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <h3 class="text-xl font-semibold mb-2 text-green-700">Features</h3>
                        <ul class="list-none space-y-3">
                            <?php if($accountType->features): ?>
                                <?php $__currentLoopData = $accountType->features->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="flex items-center p-2 bg-gray-100 rounded shadow">
                                    <i class="fas fa-check-circle text-green-500 mr-2"></i>
                                    <span class="text-gray-700"><?php echo e($feature->feature); ?></span>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <li class="text-gray-700">No features found.</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <div>
                        <h3 class="text-xl font-semibold mb-2 text-green-700">Benefits</h3>
                        <ul class="list-none space-y-3">
                            <?php if($accountType->benefits): ?>
                                <?php $__currentLoopData = $accountType->benefits->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $benefit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="flex items-center p-2 bg-gray-100 rounded shadow">
                                    <i class="fas fa-check-circle text-green-500 mr-2"></i>
                                    <span class="text-gray-700"><?php echo e($benefit->benefit); ?></span>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <li class="text-gray-700">No benefits found.</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH G:\projects\laravel\plussave_website\resources\views\livewire\account-types.blade.php ENDPATH**/ ?>