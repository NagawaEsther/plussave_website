<!-- resources/views/livewire/services-component.blade.php -->
<div class=" py-16 px-20 mb-8" >
    <h3 class="font-bold text-2xl py-6 text-center">Services We Provide</h3>

    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 py-4">
        <?php $__currentLoopData = $serviceTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('/services/' . $serviceType->route)); ?>">
            <div class="bg-white shadow-lg rounded-lg overflow-hidden hover:border border-green-700 transition duration-300 w-full md:w-auto md:max-w-none">
                <img class="w-full h-48 object-cover" src="<?php echo e(asset('storage/' . str_replace('\\', '/', $serviceType->image))); ?>" alt="Card Image">
                <div class="p-6">
                    <h2 class="text-xl font-bold mb-2 text-green-700"><?php echo e($serviceType->name); ?></h2>
                    <p class="text-gray-700 mb-4"><?php echo e($serviceType->description); ?></p>
                </div>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>


</div>
<?php /**PATH G:\projects\laravel\plussave_website\resources\views/livewire/service-types.blade.php ENDPATH**/ ?>