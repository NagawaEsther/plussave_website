<div>
    <section class="container mx-auto px-4 py-12">
        <h4 class="text-2xl mb-4 ml-3">Board Members</h4>
        <div class="flex flex-wrap">
            <?php $__currentLoopData = $boardMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boardMember): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="w-full md:w-1/4 p-4">
                    <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                        <div class="w-48 h-64 mx-auto mb-4">
                            <img src="<?php echo e(asset('storage/' . $boardMember->image)); ?>" alt="<?php echo e($boardMember->name); ?>"
                                 class="w-full h-full object-cover rounded-sm">
                        </div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-2"><?php echo e($boardMember->name); ?></h3>
                        <p class="text-green-700"><?php echo e($boardMember->position); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="mt-8 flex justify-end">
            <?php echo e($boardMembers->links()); ?>

        </div>
    </section>
</div>
<?php /**PATH G:\projects\laravel\plussave_website\resources\views/livewire/board-members.blade.php ENDPATH**/ ?>