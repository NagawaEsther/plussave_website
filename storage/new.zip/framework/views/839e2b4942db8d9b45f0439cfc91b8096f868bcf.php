<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>


    <!-- Hero Section in Blade Template -->
    <div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('carousel')->html();
} elseif ($_instance->childHasBeenRendered('rarGVqC')) {
    $componentId = $_instance->getRenderedChildComponentId('rarGVqC');
    $componentTag = $_instance->getRenderedChildComponentTagName('rarGVqC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rarGVqC');
} else {
    $response = \Livewire\Livewire::mount('carousel');
    $html = $response->html();
    $_instance->logRenderedChild('rarGVqC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
    <br>

    <!--saving--call to action-->
    <div class=" mx-auto py-16 px-6">

        <div class="flex flex-col md:flex-row items-center justify-between">
            <div class="md:w-1/2 md:ml-6 mb-5 p-6">
                <h2 class="text-3xl font-bold mb-10 text-green-700">Start Saving Smart with Plussave Financial Solutions</h2>
                <h3 class="text-gray-700 leading-relaxed mb-6 ">Looking for a reliable way to manage your finances?
                    Plussave Financial Solutions offers more than just quick loans.
                     We provide secure, hassle-free solutions designed to help you save and grow your money with confidence.
                </h3>
                <p class="text-gray-700 leading-relaxed">Join us today and start making smarter financial decisions. Your future starts here.</p>
                    <br>
                <a href="<?php echo e(route('loans.apply')); ?>"
                    class="inline-block bg-green-700 text-white font-semibold py-2  px-2 rounded hover:bg-green-800 hover:text-white hover:shadow-lg">
                    Get started today
                </a>



            </div>
            <!-- Image on the left -->
            <div class="md:w-1/2 mb-6 md:mb-0">
               <img src="<?php echo e(asset('assets/home-right-image.png')); ?>"/>
            </div>
            <!-- Title and text on the right -->

        </div>
    </div>



    <!--why save with us  max-w-3xl mx-auto  mb-8-->
    <section class="bg-gray-100">
        <div class="py-16 px-20 sm:px-8 lg:px-20">
            <div>
                <h2 class="text-3xl font-semibold text-gray-800 mb-6">Why Save with Plussave</h2>
                <p class="text-lg text-gray-600 mb-8">
                    Looking for a reliable way to manage your finances? Plussave Financial Solutions offers more than just quick loans. We provide secure, hassle-free solutions designed to help you save and grow your money with confidence.
                </p>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="p-6 bg-white rounded-lg shadow-lg flex items-center">
                    <div class="mr-4 bg-green-700 rounded-full p-2">
                        <svg class="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10 1.5a8.5 8.5 0 110 17 8.5 8.5 0 010-17zm4.33 4.612a.5.5 0 01-.163.686l-2.537 1.652.611 2.755a.5.5 0 01-.736.523l-2.894-1.615-2.894 1.615a.5.5 0 01-.736-.523l.611-2.755-2.537-1.652a.5.5 0 01-.163-.686l2.176-2.21-.285-2.913a.5.5 0 01.724-.488l2.706 1.4 2.706-1.4a.5.5 0 01.724.488l-.285 2.913 2.176 2.21z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-4">Simple and Secure</h3>
                        <p class="text-gray-600">
                            Manage your finances effortlessly with our secure savings solutions. Our commitment to security ensures your peace of mind while saving.
                        </p>
                    </div>
                </div>
                <div class="p-6 bg-white rounded-lg shadow-lg flex items-center">
                    <div class="mr-4 bg-green-700 rounded-full p-2">
                        <svg class="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10 1.5a8.5 8.5 0 110 17 8.5 8.5 0 010-17zm4.33 4.612a.5.5 0 01-.163.686l-2.537 1.652.611 2.755a.5.5 0 01-.736.523l-2.894-1.615-2.894 1.615a.5.5 0 01-.736-.523l.611-2.755-2.537-1.652a.5.5 0 01-.163-.686l2.176-2.21-.285-2.913a.5.5 0 01.724-.488l2.706 1.4 2.706-1.4a.5.5 0 01.724.488l-.285 2.913 2.176 2.21z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-4">Personalized Service</h3>
                        <p class="text-gray-600">
                            Apply for loans conveniently online or visit our branches for personalized assistance. We are here to support your financial goals every step of the way.
                        </p>
                    </div>
                </div>
                <div class="p-6 bg-white rounded-lg shadow-lg flex items-center">
                    <div class="mr-4 bg-green-700 rounded-full p-2">
                        <svg class="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10 1.5a8.5 8.5 0 110 17 8.5 8.5 0 010-17zm4.33 4.612a.5.5 0 01-.163.686l-2.537 1.652.611 2.755a.5.5 0 01-.736.523l-2.894-1.615-2.894 1.615a.5.5 0 01-.736-.523l.611-2.755-2.537-1.652a.5.5 0 01-.163-.686l2.176-2.21-.285-2.913a.5.5 0 01.724-.488l2.706 1.4 2.706-1.4a.5.5 0 01.724.488l-.285 2.913 2.176 2.21z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-4">Transparent Updates</h3>
                        <p class="text-gray-600">
                            Stay informed every step of the way with real-time updates on your loan status. Our transparent approach ensures you are always in control of your financial decisions.
                        </p>
                    </div>
                </div>
                <div class="p-6 bg-white rounded-lg shadow-lg flex items-center">
                    <div class="mr-4 bg-green-700 rounded-full p-2">
                        <svg class="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10 1.5a8.5 8.5 0 110 17 8.5 8.5 0 010-17zm4.33 4.612a.5.5 0 01-.163.686l-2.537 1.652.611 2.755a.5.5 0 01-.736.523l-2.894-1.615-2.894 1.615a.5.5 0 01-.736-.523l.611-2.755-2.537-1.652a.5.5 0 01-.163-.686l2.176-2.21-.285-2.913a.5.5 0 01.724-.488l2.706 1.4 2.706-1.4a.5.5 0 01.724.488l-.285 2.913 2.176 2.21z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-4">Start Saving Smart</h3>
                        <p class="text-gray-600">
                            Join us at Plus Save Financial Solutions today and start making smarter financial decisions. Your future starts here.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>



    


    <!--service types-->
    <section class="secondary-bg">

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('service-types')->html();
} elseif ($_instance->childHasBeenRendered('0sDQVmK')) {
    $componentId = $_instance->getRenderedChildComponentId('0sDQVmK');
    $componentTag = $_instance->getRenderedChildComponentTagName('0sDQVmK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0sDQVmK');
} else {
    $response = \Livewire\Livewire::mount('service-types');
    $html = $response->html();
    $_instance->logRenderedChild('0sDQVmK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </section>


    <!--why choose us-->
    <section class="py-12 bg-white">

        <div class="px-20 mx-auto  mb-10">
            <!-- Section Heading -->
            <div class="mb-12 ">
                <h2 class="text-2xl font-bold text-gray-800 py-6">Why Choose Us</h2>
                <div class="border-b-4  border-green-700"></div>

                <p class="text-gray-600 mt-2 py-3">Discover the benefits of our services and products today</p>
            </div>
            <!-- Reasons Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <!-- Reason 1 -->
                <div class="flex items-center p-4 bg-gray-50 rounded-lg shadow-lg">
                    <div
                        class="w-16 h-16 flex-shrink-0 bg-green-700 text-white rounded-full flex items-center justify-center">

                        <svg class="w-8 h-8 icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                            xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7">
                            </path>
                        </svg>
                    </div>
                    <div class="ml-4">
                        <h3 class="text-xl font-semibold text-gray-800">Professional Staff</h3>
                        <p class="text-gray-600 mt-2">Our team consists of experienced professionals dedicated to
                            providing top-notch services.</p>
                    </div>
                </div>
                <!-- Reason 2 -->
                <div class="flex items-center p-6 bg-gray-50 rounded-lg shadow-lg">
                    <div
                        class="w-16 h-16 flex-shrink-0 bg-green-700 text-white rounded-full flex items-center justify-center">
                        <!-- Icon (use any appropriate icon) -->
                        <svg class="w-8 h-8 icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                            xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3">
                            </path>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M9.75 9.75a8.003 8.003 0 0110.386-1.377m-.118 7.866A8.003 8.003 0 015.37 5.37">
                            </path>
                        </svg>
                    </div>
                    <div class="ml-4">
                        <h3 class="text-xl font-semibold text-gray-800">Convenient Appointments</h3>
                        <p class="text-gray-600 mt-2">We offer flexible scheduling options to accommodate your busy
                            lifestyle.</p>
                    </div>
                </div>
                <!-- Reason 3 -->
                <div class="flex items-center p-6 bg-gray-50 rounded-lg shadow-lg">
                    <div
                        class="w-16 h-16 flex-shrink-0 bg-green-700 text-white rounded-full flex items-center justify-center">
                        <!-- Icon (use any appropriate icon) -->
                        <svg class="w-8 h-8 icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                            xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M9 12h.01M15 12h.01M12 12h.01M21 12.02a9.953 9.953 0 01-9 5.98 9.953 9.953 0 01-9-5.98m18 0a9.935 9.935 0 00-4.5-8.536m-9 0A9.935 9.935 0 003 12.02m18 0c0-1.5-.375-2.91-1.07-4.165a8.017 8.017 0 00-7.93-4.87m-9 0C3.375 9.11 3 10.52 3 12.02m18 0c0 1.75-.375 3.29-1.07 4.55a8.017 8.017 0 01-7.93 4.47m-9 0C3.375 14.31 3 12.77 3 11.02m18 0a9.935 9.935 0 00-4.5-8.536M7.03 2.456a8.017 8.017 0 013.5-1.456m3.5 1.456a8.017 8.017 0 013.5 1.456m-7-1.456A8.017 8.017 0 0112 2.022M2 12c0-5.2 4-9.502 8.997-9.998M13 21c0-5.2-4-9.502-8.997-9.998">
                            </path>
                        </svg>
                    </div>
                    <div class="ml-4">
                        <h3 class="text-xl font-semibold text-gray-800">High-Quality Products</h3>
                        <p class="text-gray-600 mt-2">We use only the best products to ensure your satisfaction and
                            long-lasting results.</p>
                    </div>
                </div>
                <!-- Add more reasons as needed -->
            </div>
        </div>
    </section>



    <!--How we give loans-->
    


    <div class="secondary-bg">

        <!-- Apply for Loan Section -->
        <section class="py-16">
            <div class="container mx-auto">


                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('loan-application-form')->html();
} elseif ($_instance->childHasBeenRendered('wvV4Aiw')) {
    $componentId = $_instance->getRenderedChildComponentId('wvV4Aiw');
    $componentTag = $_instance->getRenderedChildComponentTagName('wvV4Aiw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wvV4Aiw');
} else {
    $response = \Livewire\Livewire::mount('loan-application-form');
    $html = $response->html();
    $_instance->logRenderedChild('wvV4Aiw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </section>


        <!-- Testimonial Section -->
        




    </div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<!-- Include the bodymovin library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bodymovin/5.7.6/lottie.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    console.log('Document loaded, initializing Lottie animation...');

    var animation = bodymovin.loadAnimation({
    container: document.getElementById('lottie-animation'),
    path: '<?php echo e(asset('assets/save-money.json')); ?>',
    renderer: 'svg', // Ensure renderer is set to 'svg'
    loop: true,
    autoplay: true,
    rendererSettings: {
        preserveAspectRatio: 'xMidYMid meet' // Adjust if needed
    }
});


    animation.addEventListener('DOMLoaded', function() {
        console.log('Animation loaded and ready to play.');
        animation.play();
    });
});


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\projects\laravel\plussave_website\resources\views/pages/home.blade.php ENDPATH**/ ?>