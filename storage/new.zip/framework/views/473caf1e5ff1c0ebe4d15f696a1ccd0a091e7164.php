<?php $__env->startSection('content'); ?>
    <!-- Hero Section -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hero-section', ['type' => 'about'])->html();
} elseif ($_instance->childHasBeenRendered('0TqxmeT')) {
    $componentId = $_instance->getRenderedChildComponentId('0TqxmeT');
    $componentTag = $_instance->getRenderedChildComponentTagName('0TqxmeT');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0TqxmeT');
} else {
    $response = \Livewire\Livewire::mount('hero-section', ['type' => 'about']);
    $html = $response->html();
    $_instance->logRenderedChild('0TqxmeT', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <!-- About Us -->
    <section class="py-20 bg-white">
        <div class="mx-auto px-20">
            <div class="flex flex-wrap items-center justify-center">
                <div class="w-full md:w-1/2 p-4">
                    <h2 class="text-2xl font-bold text-green-700 mb-8"><?php echo e($aboutUs->background_title); ?></h2>
                    <p class="text-gray-600 mb-4"><?php echo e($aboutUs->background_info); ?></p>
                </div>
                <div class="w-full md:w-1/2 p-4">
                    <img src="<?php echo e(asset('storage/' . $aboutUs->image)); ?>" alt="About Us Image" class="rounded-lg ">
                </div>
            </div>
        </div>
    </section>

    <!-- Our Mission Section -->
    <section class="py-20 bg-gray-100">
        <div class="mx-auto px-20 ">
            <h2 class="text-2xl font-bold text-center mb-8">Our Mission</h2>
            <p class="text-gray-600 text-center mb-8"><?php echo e($aboutUs->mision); ?></p>
            <div class="flex flex-wrap justify-center">
                <div class="w-full md:w-1/3 p-4">
                    <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                        <div class="mb-4 text-green-700">
                            <i class="fas fa-award fa-3x"></i>
                        </div>
                        <h3 class="text-2xl font-semibold text-gray-800 mb-4">Quality Service</h3>
                        <p class="text-gray-600">Our experienced professionals provide top-notch services tailored to your individual needs.</p>
                    </div>
                </div>
                <div class="w-full md:w-1/3 p-4">
                    <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                        <div class="mb-4 text-green-700">
                            <i class="fas fa-leaf fa-3x"></i>
                        </div>
                        <h3 class="text-2xl font-semibold text-gray-800 mb-4">Eco-Friendly Products</h3>
                        <p class="text-gray-600">We use products that are kind to your skin and the environment.</p>
                    </div>
                </div>
                <div class="w-full md:w-1/3 p-4">
                    <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                        <div class="mb-4 text-green-700">
                            <i class="fas fa-heart fa-3x"></i>
                        </div>
                        <h3 class="text-2xl font-semibold text-gray-800 mb-4">Customer Satisfaction</h3>
                        <p class="text-gray-600">Your satisfaction is our priority. We strive to make every visit enjoyable and relaxing.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Our Vision Section -->
    <section class="py-20">
        <div class="container mx-auto px-4">
            <h2 class="text-2xl font-bold text-center mb-8">Our Vision</h2>
            <p class="text-gray-600 text-center mb-8"><?php echo e($aboutUs->vision); ?></p>
            <div class="flex flex-wrap justify-center">
                <div class="w-full md:w-1/3 p-4">
                    <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                        <div class="mb-4 text-green-700">
                            <i class="fas fa-handshake fa-3x"></i>
                        </div>
                        <h3 class="text-2xl font-semibold text-gray-800 mb-4">Partnerships</h3>
                        <p class="text-gray-600">Building strong partnerships to expand our reach and impact.</p>
                    </div>
                </div>
                <div class="w-full md:w-1/3 p-4">
                    <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                        <div class="mb-4 text-green-700">
                            <i class="fas fa-lightbulb fa-3x"></i>
                        </div>
                        <h3 class="text-2xl font-semibold text-gray-800 mb-4">Innovation</h3>
                        <p class="text-gray-600">Driving innovation to meet future challenges and opportunities.</p>
                    </div>
                </div>
                <div class="w-full md:w-1/3 p-4">
                    <div class="bg-white p-6 rounded-lg shadow-lg text-center">
                        <div class="mb-4 text-green-700">
                            <i class="fas fa-users fa-3x"></i>
                        </div>
                        <h3 class="text-2xl font-semibold text-gray-800 mb-4">Community</h3>
                        <p class="text-gray-600">Empowering our community through education and support.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Our Team Section -->
    <section class="py-20 bg-gray-100">
        <div class=" mx-auto px-4">
            <h2 class="text-2xl font-bold text-center text-gray-800 mb-8">Our Team</h2>

            <!-- Board Members -->

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('board-members', [])->html();
} elseif ($_instance->childHasBeenRendered('FX3tPSw')) {
    $componentId = $_instance->getRenderedChildComponentId('FX3tPSw');
    $componentTag = $_instance->getRenderedChildComponentTagName('FX3tPSw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FX3tPSw');
} else {
    $response = \Livewire\Livewire::mount('board-members', []);
    $html = $response->html();
    $_instance->logRenderedChild('FX3tPSw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            <!-- Staff Members -->
            <section >

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('staff-members', [])->html();
} elseif ($_instance->childHasBeenRendered('D0AA9lN')) {
    $componentId = $_instance->getRenderedChildComponentId('D0AA9lN');
    $componentTag = $_instance->getRenderedChildComponentTagName('D0AA9lN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('D0AA9lN');
} else {
    $response = \Livewire\Livewire::mount('staff-members', []);
    $html = $response->html();
    $_instance->logRenderedChild('D0AA9lN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </section>

            <!-- Executive Members -->
            

        </div>
    </section>


    <!--Gallery-->
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\projects\laravel\plussave_website\resources\views/pages/about-us.blade.php ENDPATH**/ ?>