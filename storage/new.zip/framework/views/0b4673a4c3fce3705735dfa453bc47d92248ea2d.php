<input type="color" class="form-control" name="<?php echo e($row->field); ?>"
       value="<?php echo e(old($row->field, $dataTypeContent->{$row->field})); ?>">
<?php /**PATH G:\projects\laravel\plussave_website\vendor\tcg\voyager\resources\views\formfields\color.blade.php ENDPATH**/ ?>