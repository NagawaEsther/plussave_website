<?php $__env->startSection('content'); ?>
<section >

     <!-- Hero Section -->
 <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hero-section', ['type' => 'blog'])->html();
} elseif ($_instance->childHasBeenRendered('BOpyzao')) {
    $componentId = $_instance->getRenderedChildComponentId('BOpyzao');
    $componentTag = $_instance->getRenderedChildComponentTagName('BOpyzao');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BOpyzao');
} else {
    $response = \Livewire\Livewire::mount('hero-section', ['type' => 'blog']);
    $html = $response->html();
    $_instance->logRenderedChild('BOpyzao', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>



</section>


    <div class="container mx-auto px-4 py-4  mt-10  mb-10">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('blog-list')->html();
} elseif ($_instance->childHasBeenRendered('Xw10ZZ0')) {
    $componentId = $_instance->getRenderedChildComponentId('Xw10ZZ0');
    $componentTag = $_instance->getRenderedChildComponentTagName('Xw10ZZ0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Xw10ZZ0');
} else {
    $response = \Livewire\Livewire::mount('blog-list');
    $html = $response->html();
    $_instance->logRenderedChild('Xw10ZZ0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\projects\laravel\plussave_website\resources\views\pages\blog.blade.php ENDPATH**/ ?>