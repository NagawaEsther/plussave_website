<?php $__env->startSection('content'); ?>
<section >

     <!-- Hero Section -->
 <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hero-section', ['type' => 'contact'])->html();
} elseif ($_instance->childHasBeenRendered('FJM8QGK')) {
    $componentId = $_instance->getRenderedChildComponentId('FJM8QGK');
    $componentTag = $_instance->getRenderedChildComponentTagName('FJM8QGK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FJM8QGK');
} else {
    $response = \Livewire\Livewire::mount('hero-section', ['type' => 'contact']);
    $html = $response->html();
    $_instance->logRenderedChild('FJM8QGK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>



</section>


    <div class="container mx-auto px-4 py-4  mt-10  mb-10">
        <div class="grid grid-cols-1 sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-2 gap-20">

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('contact-us-information', [])->html();
} elseif ($_instance->childHasBeenRendered('rogFhpP')) {
    $componentId = $_instance->getRenderedChildComponentId('rogFhpP');
    $componentTag = $_instance->getRenderedChildComponentTagName('rogFhpP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rogFhpP');
} else {
    $response = \Livewire\Livewire::mount('contact-us-information', []);
    $html = $response->html();
    $_instance->logRenderedChild('rogFhpP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('contact-form', [])->html();
} elseif ($_instance->childHasBeenRendered('C0oVFgx')) {
    $componentId = $_instance->getRenderedChildComponentId('C0oVFgx');
    $componentTag = $_instance->getRenderedChildComponentTagName('C0oVFgx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('C0oVFgx');
} else {
    $response = \Livewire\Livewire::mount('contact-form', []);
    $html = $response->html();
    $_instance->logRenderedChild('C0oVFgx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        </div>
    </div>


    <!--Google maps-->
    



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\projects\laravel\plussave_website\resources\views\pages\contact-us.blade.php ENDPATH**/ ?>