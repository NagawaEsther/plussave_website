<div>
    <!-- financial-tips-component.blade.php -->
    <div class="p-6">
        <h2 class="text-2xl font-bold mb-4 text-green-700">Financial Tips and Tricks</h2>
        <?php $__currentLoopData = $financialTips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-4 p-4 border rounded flex items-start">
                <div class="mr-4 text-green-700">
                    <i class="fas fa-lightbulb fa-2x"></i>
                </div>
                <div>
                    <h3 class="text-lg font-bold"><?php echo e($tip->title); ?></h3>
                    <p><?php echo e($tip->content); ?></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php echo e($financialTips->links()); ?>

    </div>

</div>
<?php /**PATH G:\projects\laravel\plussave_website\resources\views\livewire\financial-tips-component.blade.php ENDPATH**/ ?>