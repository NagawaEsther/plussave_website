<div class="w-full overflow-x-hidden">
    <div class="relative w-full h-64 overflow-hidden">
        <div class="absolute top-0 left-0 w-full h-full flex overflow-x-auto scrolling-touch">
            <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex-shrink-0 w-full md:w-1/3 lg:w-1/4 p-2">
                    <?php
                    dump( $gallery->media_path->download->link);
                   ?>

                    <?php if($gallery->media_type == 'image'): ?>
               <img src="<?php echo e(asset('storage/' . $gallery->media_path)); ?>" class="w-full h-64 object-cover rounded shadow-lg">
                    <?php elseif($gallery->media_type == 'video'): ?>
                        <video class="w-full h-64 object-cover rounded shadow-lg" controls>
                            <source src="<?php echo e(asset('storage/' . $gallery->media_path)); ?>" type="video/mp4">
                            Your browser does not support the video tag.
                        </video>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>


<?php /**PATH G:\projects\laravel\plussave_website\resources\views\livewire\gallery-component.blade.php ENDPATH**/ ?>