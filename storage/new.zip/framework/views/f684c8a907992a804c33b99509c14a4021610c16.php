<?php $__env->startSection('content'); ?>
<section >

     <!-- Hero Section -->
 <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hero-section', ['type' => 'savings'])->html();
} elseif ($_instance->childHasBeenRendered('iwnkncq')) {
    $componentId = $_instance->getRenderedChildComponentId('iwnkncq');
    $componentTag = $_instance->getRenderedChildComponentTagName('iwnkncq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('iwnkncq');
} else {
    $response = \Livewire\Livewire::mount('hero-section', ['type' => 'savings']);
    $html = $response->html();
    $_instance->logRenderedChild('iwnkncq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</section>

<div class="py-6">

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('account-types')->html();
} elseif ($_instance->childHasBeenRendered('4NE0hpZ')) {
    $componentId = $_instance->getRenderedChildComponentId('4NE0hpZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('4NE0hpZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4NE0hpZ');
} else {
    $response = \Livewire\Livewire::mount('account-types');
    $html = $response->html();
    $_instance->logRenderedChild('4NE0hpZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\projects\laravel\plussave_website\resources\views\pages\savings.blade.php ENDPATH**/ ?>