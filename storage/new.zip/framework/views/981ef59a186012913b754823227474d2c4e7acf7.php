<?php $__env->startSection('content'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hero-section', ['type' => 'faqs'])->html();
} elseif ($_instance->childHasBeenRendered('F5U7eAN')) {
    $componentId = $_instance->getRenderedChildComponentId('F5U7eAN');
    $componentTag = $_instance->getRenderedChildComponentTagName('F5U7eAN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('F5U7eAN');
} else {
    $response = \Livewire\Livewire::mount('hero-section', ['type' => 'faqs']);
    $html = $response->html();
    $_instance->logRenderedChild('F5U7eAN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<div class="py-6">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('application-form', [])->html();
} elseif ($_instance->childHasBeenRendered('0cQCxUd')) {
    $componentId = $_instance->getRenderedChildComponentId('0cQCxUd');
    $componentTag = $_instance->getRenderedChildComponentTagName('0cQCxUd');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0cQCxUd');
} else {
    $response = \Livewire\Livewire::mount('application-form', []);
    $html = $response->html();
    $_instance->logRenderedChild('0cQCxUd', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

</div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\projects\laravel\plussave_website\resources\views\pages\apply-for-loan.blade.php ENDPATH**/ ?>