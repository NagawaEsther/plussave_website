<?php $__env->startSection('content'); ?>

<!-- Hero Section -->
 <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hero-section', ['type' => 'new-member'])->html();
} elseif ($_instance->childHasBeenRendered('146qB2n')) {
    $componentId = $_instance->getRenderedChildComponentId('146qB2n');
    $componentTag = $_instance->getRenderedChildComponentTagName('146qB2n');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('146qB2n');
} else {
    $response = \Livewire\Livewire::mount('hero-section', ['type' => 'new-member']);
    $html = $response->html();
    $_instance->logRenderedChild('146qB2n', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>




 <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('member-form', [])->html();
} elseif ($_instance->childHasBeenRendered('YvD93FM')) {
    $componentId = $_instance->getRenderedChildComponentId('YvD93FM');
    $componentTag = $_instance->getRenderedChildComponentTagName('YvD93FM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YvD93FM');
} else {
    $response = \Livewire\Livewire::mount('member-form', []);
    $html = $response->html();
    $_instance->logRenderedChild('YvD93FM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\projects\laravel\plussave_website\resources\views\pages\member.blade.php ENDPATH**/ ?>