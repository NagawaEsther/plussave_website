<div class="py-6 px-10 bg-white shadow-md rounded">
    <h4 class="font-bold text-lg p-6">Contact Information</h4>

    <div class="flex justify-start py-4 px-6">
        <i class="fas fa-phone text-green-700 w-10"></i>
        <p class="text-base px-8">Contact Number: <?php echo e($contactInformation->phone); ?></p>
    </div>

    <div class="flex justify-start py-4 px-6">
        <i class="fas fa-envelope text-green-700 w-10"></i>
        <p class="text-base px-8">Email Address: <?php echo e($contactInformation->email); ?></p>
    </div>

    <div class="flex justify-start py-4 px-6">
        <i class="fas fa-map-marker-alt text-green-700 w-10"></i>
        <p class="text-base px-8">Location: <?php echo e($contactInformation->address); ?></p>
    </div>

    <div class="flex justify-start py-4 px-6">
        <i class="fab fa-twitter text-green-700 w-10"></i>
        <p class="text-base px-8">Twitter: <?php echo e($contactInformation->twitter); ?></p>
    </div>

    <div class="flex justify-start py-4 px-6">
        <i class="fab fa-instagram text-green-700 w-10"></i>
        <p class="text-base px-8">Instagram: <?php echo e($contactInformation->instagram); ?></p>
    </div>
</div>
<?php /**PATH G:\projects\laravel\plussave_website\resources\views\livewire\contact-us-information.blade.php ENDPATH**/ ?>