<div >
    <!-- savings-plans-component.blade.php -->
<div class="p-6">
    <h2 class="text-2xl font-bold mb-4">Savings Plans</h2>
    <?php $__currentLoopData = $savingsPlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="mb-4 p-4 border rounded flex items-start">
        <div class="mr-4 text-green-700">
            <i class="fas fa-piggy-bank fa-2x"></i>
        </div>
        <div>
            <h3 class="text-lg font-bold"><?php echo e($plan->title); ?></h3>
            <p><?php echo e($plan->description); ?></p>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo e($savingsPlans->links()); ?>

</div>

</div>
<?php /**PATH G:\projects\laravel\plussave_website\resources\views\livewire\savings-plans-component.blade.php ENDPATH**/ ?>