<div class="container mx-auto px-4 py-8">
    <h2 class="text-4xl font-bold text-center mb-8">Latest Blogs</h2>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white p-6 rounded-lg shadow-lg">
                <h3 class="text-xl font-semibold mb-2"><?php echo e($blog->title); ?></h3>
                <p class="text-gray-700 mb-4"><?php echo e($blog->content); ?></p>
                <?php if($blog->media_type === 'image'): ?>
                    <img src="<?php echo e(asset('storage/' . $blog->media_path)); ?>" alt="<?php echo e($blog->title); ?>" class="w-full h-64 object-cover rounded-md">
                <?php elseif($blog->media_type === 'video'): ?>
                    <video controls class="w-full h-64 rounded-md">
                        <source src="<?php echo e(asset('storage/' . $blog->media_path)); ?>" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Pagination Links -->
    <div class="mt-8">
        <?php echo e($blogs->links()); ?>

    </div>
</div>
<?php /**PATH G:\projects\laravel\plussave_website\resources\views\livewire\blog-list.blade.php ENDPATH**/ ?>