<?php $__env->startSection('content'); ?>
   <!-- Hero Section -->
   <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hero-section', ['type' => 'faqs'])->html();
} elseif ($_instance->childHasBeenRendered('6t3VLDF')) {
    $componentId = $_instance->getRenderedChildComponentId('6t3VLDF');
    $componentTag = $_instance->getRenderedChildComponentTagName('6t3VLDF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('6t3VLDF');
} else {
    $response = \Livewire\Livewire::mount('hero-section', ['type' => 'faqs']);
    $html = $response->html();
    $_instance->logRenderedChild('6t3VLDF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <div class="container mx-auto py-12">

        <section id="faq">
            <h2 class="text-3xl font-bold mb-6 text-center text-gray-900">Frequently Asked Questions</h2>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('faqs', [])->html();
} elseif ($_instance->childHasBeenRendered('VIz56yB')) {
    $componentId = $_instance->getRenderedChildComponentId('VIz56yB');
    $componentTag = $_instance->getRenderedChildComponentTagName('VIz56yB');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('VIz56yB');
} else {
    $response = \Livewire\Livewire::mount('faqs', []);
    $html = $response->html();
    $_instance->logRenderedChild('VIz56yB', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\projects\laravel\plussave_website\resources\views\pages\faqs.blade.php ENDPATH**/ ?>