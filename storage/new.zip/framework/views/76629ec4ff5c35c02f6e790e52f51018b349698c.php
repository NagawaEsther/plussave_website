<!-- Simplicity is the consequence of refined emotions. - Jean D'Alembert -->
<div class="hero" style="background-image: url('<?php echo e($backgroundImage); ?>');">
    <div class="hero-text">
        <h1><?php echo e($text); ?></h1>
        <a href="#" class="btn"><?php echo e($buttonText); ?></a>
    </div>
</div>
<?php /**PATH G:\projects\laravel\plussave_website\resources\views\components\hero-section.blade.php ENDPATH**/ ?>