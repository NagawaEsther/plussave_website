<div>

    <section class="relative z-30 bg-cover bg-center  h-96" style="background-image: url('<?php echo e(asset('storage/' . str_replace('\\', '/', $backgroundImage))); ?>');">
        
        <div class="container mx-auto px-4 h-full flex items-center justify-center">
            <div class="relative text-center text-white">
                <h1 class="text-4xl font-bold mb-4 slide-right"><?php echo e($title); ?></h1>
                <p class="text-xl mb-8"><?php echo e($sub_title); ?></p>
                <a href="#more" class="inline-bloc bg-green-700 text-whitefont-semibold py-3 px-6 rounded-md shadow-lg hover:bg-gray-100 hover:text-green-700">Learn More</a> <!-- Updated button text color to green -->
            </div>
        </div>
    </section>





</div>
<?php /**PATH G:\projects\laravel\plussave_website\resources\views/livewire/hero-section.blade.php ENDPATH**/ ?>