<?php $__env->startSection('content'); ?>
    <section>

        <!-- Hero Section -->
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hero-section', ['type' => 'loans'])->html();
} elseif ($_instance->childHasBeenRendered('oieCEnK')) {
    $componentId = $_instance->getRenderedChildComponentId('oieCEnK');
    $componentTag = $_instance->getRenderedChildComponentTagName('oieCEnK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('oieCEnK');
} else {
    $response = \Livewire\Livewire::mount('hero-section', ['type' => 'loans']);
    $html = $response->html();
    $_instance->logRenderedChild('oieCEnK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </section>


    <!--Loan Information-->
    <section>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('loan-information-section', [])->html();
} elseif ($_instance->childHasBeenRendered('ci8ADSa')) {
    $componentId = $_instance->getRenderedChildComponentId('ci8ADSa');
    $componentTag = $_instance->getRenderedChildComponentTagName('ci8ADSa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ci8ADSa');
} else {
    $response = \Livewire\Livewire::mount('loan-information-section', []);
    $html = $response->html();
    $_instance->logRenderedChild('ci8ADSa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </section>



    <!--Loan Types-->
    <section class="secondary-bg">

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('loan-types')->html();
} elseif ($_instance->childHasBeenRendered('VJfyZSO')) {
    $componentId = $_instance->getRenderedChildComponentId('VJfyZSO');
    $componentTag = $_instance->getRenderedChildComponentTagName('VJfyZSO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('VJfyZSO');
} else {
    $response = \Livewire\Livewire::mount('loan-types');
    $html = $response->html();
    $_instance->logRenderedChild('VJfyZSO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </section>



    <!--loan calculator-->
    <div class="flex flex-wrap items-center justify-center">

        <div class="w-full md:w-1/2 mb-4 md:mb-0">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('loan-calculator', [])->html();
} elseif ($_instance->childHasBeenRendered('LCm8Cpa')) {
    $componentId = $_instance->getRenderedChildComponentId('LCm8Cpa');
    $componentTag = $_instance->getRenderedChildComponentTagName('LCm8Cpa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LCm8Cpa');
} else {
    $response = \Livewire\Livewire::mount('loan-calculator', []);
    $html = $response->html();
    $_instance->logRenderedChild('LCm8Cpa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>


        <div class="">
            <img src="<?php echo e(asset('assets/loan-calculator.png')); ?>" alt="Loan Calculator Image" class="w-full ">
        </div>
    </div>

    <!--How to apply for loans-->
    <div class="flex flex-wrap items-center justify-center secondary-bg container p-8">

        <!-- iPhone frame image column -->
        <div >
            <div class="relative">
                <img src="<?php echo e(asset('assets/loan-application-image.png')); ?>" alt="iPhone Frame" class=" w-70 h-96">

            </div>
        </div>

        <!-- Column for the steps -->
        <div class="w-full md:w-1/2">
            <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">

                <h2 class="text-xl font-bold mb-4">Loan Application Steps</h2>
                <!-- Stepper -->
                <div class="flex items-center mb-4">
                    <div class="bg-green-700 rounded-full h-8 w-8 flex items-center justify-center">
                        <span class="text-white">1</span>
                    </div>
                    <p class="ml-4">Step 1: Fill out the loan application form.</p>
                </div>

                <div class="flex items-center mb-4">
                    <div class="bg-green-700 rounded-full h-8 w-8 flex items-center justify-center">
                        <span class="text-white">2</span>
                    </div>
                    <p class="ml-4">Step 2: Provide necessary documents and information.</p>
                </div>

                <div class="flex items-center mb-4">
                    <div class="bg-green-700 rounded-full h-8 w-8 flex items-center justify-center">
                        <span class="text-white">3</span>
                    </div>
                    <p class="ml-4">Step 3: Review and submit your application.</p>
                </div>

                <div class="flex items-center">
                    <div class="bg-green-700 rounded-full h-8 w-8 flex items-center justify-center">
                        <span class="text-white">4</span>
                    </div>
                    <p class="ml-4">Step 4: Wait for loan approval and disbursement.</p>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\projects\laravel\plussave_website\resources\views\pages\loans.blade.php ENDPATH**/ ?>