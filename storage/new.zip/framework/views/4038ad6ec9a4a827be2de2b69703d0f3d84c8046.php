<?php $__env->startSection('content'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hero-section', ['type' => 'faqs'])->html();
} elseif ($_instance->childHasBeenRendered('aYp6Qb5')) {
    $componentId = $_instance->getRenderedChildComponentId('aYp6Qb5');
    $componentTag = $_instance->getRenderedChildComponentTagName('aYp6Qb5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('aYp6Qb5');
} else {
    $response = \Livewire\Livewire::mount('hero-section', ['type' => 'faqs']);
    $html = $response->html();
    $_instance->logRenderedChild('aYp6Qb5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<div class="py-6">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('loan-calculator', [])->html();
} elseif ($_instance->childHasBeenRendered('DsHmTiM')) {
    $componentId = $_instance->getRenderedChildComponentId('DsHmTiM');
    $componentTag = $_instance->getRenderedChildComponentTagName('DsHmTiM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('DsHmTiM');
} else {
    $response = \Livewire\Livewire::mount('loan-calculator', []);
    $html = $response->html();
    $_instance->logRenderedChild('DsHmTiM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

</div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\projects\laravel\plussave_website\resources\views\pages\loan-calculator.blade.php ENDPATH**/ ?>