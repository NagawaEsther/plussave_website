<?php $__env->startSection('title', 'Financial Literacy'); ?>

<?php $__env->startSection('content'); ?>
<!-- Hero Section -->
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hero-section', ['type' => 'financial-literacy'])->html();
} elseif ($_instance->childHasBeenRendered('eVBhurO')) {
    $componentId = $_instance->getRenderedChildComponentId('eVBhurO');
    $componentTag = $_instance->getRenderedChildComponentTagName('eVBhurO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('eVBhurO');
} else {
    $response = \Livewire\Livewire::mount('hero-section', ['type' => 'financial-literacy']);
    $html = $response->html();
    $_instance->logRenderedChild('eVBhurO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<!-- Financial Tips and Tricks Section -->
<div class="container mx-auto py-16">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('financial-tips-component')->html();
} elseif ($_instance->childHasBeenRendered('eYhzgzX')) {
    $componentId = $_instance->getRenderedChildComponentId('eYhzgzX');
    $componentTag = $_instance->getRenderedChildComponentTagName('eYhzgzX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('eYhzgzX');
} else {
    $response = \Livewire\Livewire::mount('financial-tips-component');
    $html = $response->html();
    $_instance->logRenderedChild('eYhzgzX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>

<!-- Savings Plans Section -->
<div class="container secondary-bg mx-auto py-16 ">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('savings-plans-component')->html();
} elseif ($_instance->childHasBeenRendered('v62WSMh')) {
    $componentId = $_instance->getRenderedChildComponentId('v62WSMh');
    $componentTag = $_instance->getRenderedChildComponentTagName('v62WSMh');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('v62WSMh');
} else {
    $response = \Livewire\Livewire::mount('savings-plans-component');
    $html = $response->html();
    $_instance->logRenderedChild('v62WSMh', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>

<!-- Financial Advice Section -->
<div class="container mx-auto py-16">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('financial-advice-component')->html();
} elseif ($_instance->childHasBeenRendered('APpUkX6')) {
    $componentId = $_instance->getRenderedChildComponentId('APpUkX6');
    $componentTag = $_instance->getRenderedChildComponentTagName('APpUkX6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('APpUkX6');
} else {
    $response = \Livewire\Livewire::mount('financial-advice-component');
    $html = $response->html();
    $_instance->logRenderedChild('APpUkX6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('livewire:load', function () {
        Livewire.on('pageChanged', () => {
            const elements = document.querySelectorAll('.page-section');
            elements.forEach(element => {
                element.classList.add('transition-opacity', 'duration-500', 'ease-in-out');
                element.style.opacity = '0';
                setTimeout(() => {
                    element.style.opacity = '1';
                }, 500);
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\projects\laravel\plussave_website\resources\views\pages\financial-literacy.blade.php ENDPATH**/ ?>