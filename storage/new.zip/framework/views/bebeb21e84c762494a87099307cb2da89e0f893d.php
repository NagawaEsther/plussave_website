<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Form Submission</title>
</head>
<body>
    <h2>Dear <?php echo e($data['name']); ?>,</h2>
    <p>Thank you for contacting Plussave Financial Solutions. We have received your message:</p>
    <p><?php echo e($data['message']); ?></p>
    <p>We will get back to you shortly.</p>
</body>
</html>
<?php /**PATH G:\projects\laravel\plussave_website\resources\views\emails\contact-form-mail.blade.php ENDPATH**/ ?>