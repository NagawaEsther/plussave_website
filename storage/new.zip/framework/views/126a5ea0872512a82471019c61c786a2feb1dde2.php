<?php $__env->startSection('title', 'Other Financial Services'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Hero Section -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('hero-section', ['type' => 'other-financial-services'])->html();
} elseif ($_instance->childHasBeenRendered('hx0dgLA')) {
    $componentId = $_instance->getRenderedChildComponentId('hx0dgLA');
    $componentTag = $_instance->getRenderedChildComponentTagName('hx0dgLA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hx0dgLA');
} else {
    $response = \Livewire\Livewire::mount('hero-section', ['type' => 'other-financial-services']);
    $html = $response->html();
    $_instance->logRenderedChild('hx0dgLA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <!-- Financial Services Section -->
    <div class="container mx-auto  px-3 py-16">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('other-financial-services-component')->html();
} elseif ($_instance->childHasBeenRendered('cJsYzAY')) {
    $componentId = $_instance->getRenderedChildComponentId('cJsYzAY');
    $componentTag = $_instance->getRenderedChildComponentTagName('cJsYzAY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('cJsYzAY');
} else {
    $response = \Livewire\Livewire::mount('other-financial-services-component');
    $html = $response->html();
    $_instance->logRenderedChild('cJsYzAY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('livewire:load', function () {
        Livewire.on('pageChanged', () => {
            const elements = document.querySelectorAll('.page-section');
            elements.forEach(element => {
                element.classList.add('transition-opacity', 'duration-500', 'ease-in-out');
                element.style.opacity = '0';
                setTimeout(() => {
                    element.style.opacity = '1';
                }, 500);
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\projects\laravel\plussave_website\resources\views\pages\other-financial-services.blade.php ENDPATH**/ ?>